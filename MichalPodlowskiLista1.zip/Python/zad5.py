import os
import builtins
import math

print("bez reszty")
print(1//3)
print(2//3)
print(11//2)
print(7//2)
print(3//2)
print("round")
print(round(1/2))
print(round(2/3))
print(round(11/2))
print(round(7/2))
print(round(3/2))
print("floor")
print(math.floor(1/2))
print(math.floor(2/3))
print(math.floor(11/2))
print(math.floor(7/2))
print(math.floor(3/2))
print("mnożenie bez reszty zwyczajnie ignoruje miejsca dziesiętne i zwraca liczbe całkowitą, zaokrąglanie round zaokrągla w górę, lub w dół w zależności od rozwinięcia dziesiętnego, floor działa podobnie jak dzielenie bez reszty, z automatu zaokrąglając w dół")

os.system("PAUSE")


