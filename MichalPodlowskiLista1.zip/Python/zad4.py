import os
import builtins
dir(builtins)
help(print)
print("Ala ma kota")
print(2+2)
print(2**5,"\t",35//2,"\t",35/2,"\t",35%2)
print(2**5,"\n",35//2,"\n",35/2,"\n",35%2)

os.system("PAUSE")

