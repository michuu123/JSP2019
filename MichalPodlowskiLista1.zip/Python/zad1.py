import os
a=input()
b=input()
suma=a+b
print(suma)
os.system("PAUSE")
# tego się nie spodziewałem, system zwraca wynik poprzez wydrukowanie w konsoli obydwu liczb, ponieważ najwyraźniej interpretuje je jako tablice znaków, nie natomiast faktyczne liczby
