
import os
import math
import builtins
print("podaj a")
a=int(input())
print("podaj b, mniejsze od a")
b=int(input())
z=b%a
z*=(z+3)
print(z)
os.system("PAUSE")
