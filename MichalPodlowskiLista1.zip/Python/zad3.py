import math
import os
print("Podaj bok a")
a=int(input())
print("Podaj bok b")
b=int(input())
print("Podaj kąt")
c=int(input())
y=0.5*a*b*math.sin(math.radians(c))
print(y)
os.system("PAUSE")

