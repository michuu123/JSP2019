import math
import os
y=0.5*3*4*math.sin(math.radians(47))
print(y)
os.system("PAUSE")
