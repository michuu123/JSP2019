import os
print("w trybie interaktywnym _ przyjmuje wartość ostatniej zwróconej przez interpretatora \n (czy tam interpretora, nie mam pojęcia, piszę to dość późno) \n dla przykładu, jeżeli ostatnią zwróconą wartością jest 10, wtedy _ przyjmuje właśnie taką wartość, \n z kolei _*20 przyjmuje wartość 200. Jeżeli po tej sekwencji znowu dopiszemy _ * 20 naszym oczom ukaże się piękne 4000")
os.system("PAUSE")
